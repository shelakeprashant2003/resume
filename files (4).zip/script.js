// Respect users who prefer less motion
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// 1. Mobile menu toggle
const burger = document.getElementById('burger');
const menu = document.getElementById('menu');
burger.addEventListener('click', () => {
  const open = menu.classList.toggle('open');
  burger.classList.toggle('open', open);
  burger.setAttribute('aria-expanded', open);
});
menu.querySelectorAll('a').forEach(link =>
  link.addEventListener('click', () => {
    menu.classList.remove('open');
    burger.classList.remove('open');
    burger.setAttribute('aria-expanded', 'false');
  })
);

// 2. Reveal elements as they scroll into view
const reveals = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && !reduceMotion) {
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('show'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  reveals.forEach(el => io.observe(el));
} else {
  reveals.forEach(el => el.classList.add('show'));
}

// 3. Highlight the nav link of the section currently in view
const links = document.querySelectorAll('.menu a');
const sections = [...links].map(a => document.querySelector(a.getAttribute('href')));
function setActive() {
  const y = window.scrollY + 120;
  let current = 0;
  sections.forEach((s, i) => { if (s && s.offsetTop <= y) current = i; });
  links.forEach((a, i) => a.classList.toggle('active', i === current));
}
window.addEventListener('scroll', setActive, { passive: true });
setActive();

// 4. Terminal typing effect
const typed = document.getElementById('typed');
const text = typed.dataset.text;
if (reduceMotion) {
  typed.textContent = text;
} else {
  let i = 0;
  (function type() {
    typed.textContent = text.slice(0, ++i);
    if (i < text.length) setTimeout(type, 28);
  })();
}
